/**
 * Service to fetch game cover art from the backend (which proxies to IGDB)
 */
export const fetchGameCover = async (title: string): Promise<string | undefined> => {
  // IGDB requires a server-side proxy or Supabase Edge Function to keep the client secret safe.
  // For now, we return undefined. You can implement this using a Supabase Edge Function.
  console.log('Game cover fetching is disabled in static mode. Title:', title);
  return undefined;
};
